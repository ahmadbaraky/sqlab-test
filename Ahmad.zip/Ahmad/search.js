var path = require('path'), fs=require('fs');

function fromDir(startPath,ext,str){

    console.log('Starting from dir '+startPath+'/');

    if (!fs.existsSync(startPath)){
        console.log("no dir ",startPath);
        return;
    }

    var files=fs.readdirSync(startPath);
    for(var i=0;i<files.length;i++){
        var filename=path.join(startPath,files[i]);
        var stat = fs.lstatSync(filename);
        if (stat.isDirectory()){
            fromDir(filename,ext,str); //recurse
        }
        else if (filename.indexOf(ext) >= 0 && filename.indexOf(str) >= 0) {
            console.log('-- found: ',filename);
        };
    };
};

var ext = process.argv[2];
var str = process.argv[3];
fromDir(process.cwd(),`.${ext}`, str);